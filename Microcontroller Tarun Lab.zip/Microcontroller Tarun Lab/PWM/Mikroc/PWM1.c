void main() {
      short current_duty_1 = 10;
      TRISD = 0xff;
      TRISC = 0x00;
      PWM1_Init(5000);
      PWM1_start();
      PWM1_set_duty(current_duty_1);

      while(1){
        if(portd.f0 == 0){
        delay_ms(200);
        if(portd.f0 == 0) {
           current_duty_1 = current_duty_1 + 10;
           PWM1_set_duty(current_duty_1);
        delay_ms(10);
        }

        }
        if(portd.f1 == 0){
         delay_ms(200);
         if(portd.f1 == 0){
         current_duty_1 = current_duty_1 - 10;
         PWM1_set_duty(current_duty_1);
         delay_ms(10);
         }

        }

      }

}