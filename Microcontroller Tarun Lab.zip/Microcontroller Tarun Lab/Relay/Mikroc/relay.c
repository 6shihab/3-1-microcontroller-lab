void main()
{
  TRISB=0x00;
  PORTB=0x00; 
  while(1)
  {
      portB.f0=0xff;
      portB.f1=0xff;
      portB.f2=0x00;
      delay_ms(2000);
      portB.f0=0x00;
      portB.f1=0x00;
      portB.f2=0xff;
      delay_ms(2000);

}
}
