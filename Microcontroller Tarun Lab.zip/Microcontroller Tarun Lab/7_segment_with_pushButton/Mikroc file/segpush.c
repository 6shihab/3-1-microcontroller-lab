int i=-1;
unsigned int arr[]={ 0x3F, 0x06, 0x5B   ,0x4F ,0x66 ,0x6D, 0x7D ,0x07,0x7F,0x6F};
void main()
{
  TRISD= 0xff;
  TRISB= 0x00;
  PORTB = 0x00;
  while(1)
  {
  if(PORTD.F0 == 0x00)
  {
       Delay_ms(200);
       if(PORTD.F0 == 0x00)
       {
         i++;
         PORTB= arr[i];
         if(i>9){
         portb=0x3F;
         i=0;
       }
    }
  }
  if(PORTD.F1 == 0x00)
  {
       Delay_ms(200);
       if(PORTD.F1 == 0x00)
       {
         i--;
         PORTB= arr[i];
         if(i<0){
         portb=0x6F;
         i=9;
       }
    }
  }
 }
}