int i=0;
int arr[]={ 0x3F, 0x06, 0x5B   ,0x4F ,0x66 ,0x6D, 0x7D ,0x07,0x7F,0x6F};
void main()
{
  TRISB= 0x00;
  PORTB = 0x00;
  while(1)
  {
     portB=arr[i];
     delay_ms(1000);
     i++;
     if(i>9){
        i=0;
     }
  }
}